﻿namespace Events;

public class GameStartedEvent
{
    public Guid GameId { get; set; }
}