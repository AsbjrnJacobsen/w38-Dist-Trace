namespace Events;

public enum Move
{
    Rock,
    Paper,
    Scissor
}